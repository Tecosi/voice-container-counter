import { useEffect, useMemo, useState } from "react";
import SpeechRecognition, { useSpeechRecognition } from "react-speech-recognition";
import type { Container, ParsedLine, SummaryLine } from "./types";
import { api } from "./api";

type DraftLine = ParsedLine & { id: string };

function uid() {
  return Math.random().toString(16).slice(2) + Date.now().toString(16);
}

export default function App() {
  const [containerLabel, setContainerLabel] = useState("Contenant 001");
  const [container, setContainer] = useState<Container | null>(null);
  const [summary, setSummary] = useState<SummaryLine[]>([]);
  const [draftLines, setDraftLines] = useState<DraftLine[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const { transcript, interimTranscript, listening, resetTranscript, browserSupportsSpeechRecognition } =
    useSpeechRecognition();

  const liveTranscript = useMemo(() => {
    const t = [transcript, interimTranscript].filter(Boolean).join(" ").trim();
    return t;
  }, [transcript, interimTranscript]);

  async function refreshAll(containerId: string) {
    const c = await api.getContainer(containerId);
    setContainer(c);
    const s = await api.getSummary(containerId);
    setSummary(s);
  }

  async function onCreateContainer() {
    setError(null);
    setBusy("createContainer");
    try {
      const c = await api.createContainer(containerLabel.trim());
      setContainer(c);
      setDraftLines([]);
      resetTranscript();
      const s = await api.getSummary(c.id);
      setSummary(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }

  async function onParseAndPrepare() {
    if (!container) {
      setError("Crée d’abord un contenant.");
      return;
    }
    setError(null);
    setBusy("parse");
    try {
      const text = liveTranscript.trim();
      if (!text) {
        setError("Aucun texte à parser (dictée vide).");
        return;
      }
      const out = await api.parse(text);
      setDraftLines(out.lines.map((l) => ({ ...l, id: uid() })));
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }

  async function onCommitDraftToContainer() {
    if (!container) return;
    setError(null);
    setBusy("commit");
    try {
      for (const l of draftLines) {
        await api.addLine(container.id, l.itemLabel, l.quantity);
      }
      setDraftLines([]);
      resetTranscript();
      await refreshAll(container.id);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }

  async function onUpdateExistingLine(lineId: string, patch: { itemLabel?: string; quantity?: number }) {
    if (!container) return;
    setError(null);
    setBusy("updateLine");
    try {
      const c = await api.updateLine(container.id, lineId, patch);
      setContainer(c);
      const s = await api.getSummary(container.id);
      setSummary(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }

  useEffect(() => {
    setError(null);
  }, [containerLabel]);

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <div>
          <div style={styles.title}>Voice Container Counter</div>
          <div style={styles.subtitle}>Dictée → parsing → correction → totaux par contenant</div>
        </div>
      </div>

      {error && <div style={styles.error}>Erreur : {error}</div>}

      <section style={styles.card}>
        <h2 style={styles.h2}>Contenant</h2>

        <div style={styles.rowWrap}>
          <input
            style={styles.input}
            value={containerLabel}
            onChange={(e) => setContainerLabel(e.target.value)}
            placeholder="Label (ex: Contenant 001)"
          />
          <button
            style={styles.button}
            onClick={onCreateContainer}
            disabled={busy !== null || !containerLabel.trim()}
          >
            Créer un contenant
          </button>
        </div>

        {container ? (
          <div style={styles.kv}>
            <div><b>ID</b> : {container.id}</div>
            <div><b>Label</b> : {container.label}</div>
          </div>
        ) : (
          <div style={styles.muted}>Aucun contenant courant.</div>
        )}
      </section>

      <section style={styles.card}>
        <h2 style={styles.h2}>Saisie vocale</h2>

        {!browserSupportsSpeechRecognition ? (
          <div style={styles.error}>
            Ton navigateur ne supporte pas la reconnaissance vocale Web Speech API.
            Essaie Chrome/Edge (sur desktop/tablette).
          </div>
        ) : (
          <>
            <div style={styles.rowWrap}>
              <button
                style={listening ? styles.buttonDanger : styles.button}
                onClick={() => {
                  setError(null);
                  if (!listening) {
                    SpeechRecognition.startListening({ continuous: true, language: "fr-FR" });
                  } else {
                    SpeechRecognition.stopListening();
                  }
                }}
                disabled={busy !== null || !container}
                title={!container ? "Crée un contenant d'abord" : undefined}
              >
                {listening ? "Arrêter la dictée" : "Démarrer la dictée"}
              </button>

              <button
                style={styles.buttonSecondary}
                onClick={() => resetTranscript()}
                disabled={busy !== null}
              >
                Effacer
              </button>

              <button
                style={styles.button}
                onClick={onParseAndPrepare}
                disabled={busy !== null || !container || !liveTranscript.trim()}
              >
                Envoyer (parser)
              </button>
            </div>

            <div style={styles.textArea}>
              <div style={styles.mutedSmall}>Transcription (en cours) :</div>
              <div style={styles.transcript}>{liveTranscript || "…"}</div>
            </div>

            {draftLines.length > 0 && (
              <div style={{ marginTop: 12 }}>
                <div style={styles.rowWrap}>
                  <div style={{ fontWeight: 600 }}>Lignes proposées (éditables avant insertion)</div>
                  <button
                    style={styles.button}
                    onClick={onCommitDraftToContainer}
                    disabled={busy !== null || !container}
                  >
                    Ajouter au contenant
                  </button>
                </div>

                <DraftTable
                  lines={draftLines}
                  onChange={(id, patch) => {
                    setDraftLines((prev) =>
                      prev.map((l) => (l.id === id ? { ...l, ...patch } : l))
                    );
                  }}
                  onRemove={(id) => setDraftLines((prev) => prev.filter((l) => l.id !== id))}
                />
              </div>
            )}
          </>
        )}
      </section>

      <section style={styles.card}>
        <h2 style={styles.h2}>Lignes du contenant</h2>

        {!container ? (
          <div style={styles.muted}>Crée un contenant pour afficher les lignes.</div>
        ) : container.lines.length === 0 ? (
          <div style={styles.muted}>Aucune ligne.</div>
        ) : (
          <ExistingLinesTable
            lines={container.lines}
            onSave={(lineId, patch) => onUpdateExistingLine(lineId, patch)}
          />
        )}
      </section>

      <section style={styles.card}>
        <h2 style={styles.h2}>Résumé</h2>
        {!container ? (
          <div style={styles.muted}>Crée un contenant.</div>
        ) : summary.length === 0 ? (
          <div style={styles.muted}>Aucun total.</div>
        ) : (
          <div style={styles.summaryGrid}>
            {summary.map((s) => (
              <div key={s.itemLabel} style={styles.summaryItem}>
                <div style={{ fontWeight: 600 }}>{s.itemLabel}</div>
                <div style={{ fontSize: 22 }}>{s.totalQuantity}</div>
              </div>
            ))}
          </div>
        )}
      </section>

      <footer style={styles.footer}>
        <div style={styles.mutedSmall}>
          Note : la reconnaissance vocale Web Speech API fonctionne sur “localhost” (contexte sécurisé),
          et généralement mieux sur Chrome/Edge.
        </div>
      </footer>
    </div>
  );
}

function DraftTable(props: {
  lines: DraftLine[];
  onChange: (id: string, patch: Partial<DraftLine>) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <div style={styles.tableWrap}>
      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.th}>Article</th>
            <th style={styles.thQty}>Quantité</th>
            <th style={styles.thActions}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {props.lines.map((l) => (
            <tr key={l.id}>
              <td style={styles.td}>
                <input
                  style={styles.inputInline}
                  value={l.itemLabel}
                  onChange={(e) => props.onChange(l.id, { itemLabel: e.target.value })}
                />
              </td>
              <td style={styles.tdQty}>
                <input
                  style={styles.inputInline}
                  type="number"
                  value={l.quantity}
                  onChange={(e) => props.onChange(l.id, { quantity: Number(e.target.value) })}
                />
              </td>
              <td style={styles.tdActions}>
                <button style={styles.buttonDangerSmall} onClick={() => props.onRemove(l.id)}>
                  Retirer
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ExistingLinesTable(props: {
  lines: { id: string; itemLabel: string; quantity: number }[];
  onSave: (lineId: string, patch: { itemLabel?: string; quantity?: number }) => void;
}) {
  const [editId, setEditId] = useState<string | null>(null);
  const [tmpLabel, setTmpLabel] = useState("");
  const [tmpQty, setTmpQty] = useState<number>(0);

  return (
    <div style={styles.tableWrap}>
      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.th}>Article</th>
            <th style={styles.thQty}>Quantité</th>
            <th style={styles.thActions}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {props.lines.map((l) => {
            const isEdit = editId === l.id;
            return (
              <tr key={l.id}>
                <td style={styles.td}>
                  {isEdit ? (
                    <input
                      style={styles.inputInline}
                      value={tmpLabel}
                      onChange={(e) => setTmpLabel(e.target.value)}
                    />
                  ) : (
                    l.itemLabel
                  )}
                </td>
                <td style={styles.tdQty}>
                  {isEdit ? (
                    <input
                      style={styles.inputInline}
                      type="number"
                      value={tmpQty}
                      onChange={(e) => setTmpQty(Number(e.target.value))}
                    />
                  ) : (
                    l.quantity
                  )}
                </td>
                <td style={styles.tdActions}>
                  {isEdit ? (
                    <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", flexWrap: "wrap" }}>
                      <button
                        style={styles.buttonSmall}
                        onClick={() => {
                          props.onSave(l.id, { itemLabel: tmpLabel.trim(), quantity: tmpQty });
                          setEditId(null);
                        }}
                      >
                        Sauver
                      </button>
                      <button style={styles.buttonSecondarySmall} onClick={() => setEditId(null)}>
                        Annuler
                      </button>
                    </div>
                  ) : (
                    <button
                      style={styles.buttonSmall}
                      onClick={() => {
                        setEditId(l.id);
                        setTmpLabel(l.itemLabel);
                        setTmpQty(l.quantity);
                      }}
                      title="Éditer"
                    >
                      Éditer
                    </button>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

const styles: Record<string, any> = {
  page: {
    fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif",
    maxWidth: 1100,
    margin: "0 auto",
    padding: "18px 14px",
    color: "#111"
  },
  header: { display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 },
  title: { fontSize: 24, fontWeight: 800 },
  subtitle: { color: "#555", marginTop: 4 },
  card: {
    border: "1px solid #e6e6e6",
    borderRadius: 14,
    padding: 14,
    marginTop: 12,
    boxShadow: "0 2px 10px rgba(0,0,0,0.04)"
  },
  h2: { margin: 0, marginBottom: 10, fontSize: 16 },
  rowWrap: { display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" },
  input: { padding: "10px 12px", borderRadius: 10, border: "1px solid #ddd", minWidth: 240, flex: "1 1 240px" },
  button: {
    padding: "10px 12px",
    borderRadius: 10,
    border: "1px solid #222",
    background: "#222",
    color: "#fff",
    cursor: "pointer"
  },
  buttonSecondary: {
    padding: "10px 12px",
    borderRadius: 10,
    border: "1px solid #bbb",
    background: "#fff",
    color: "#111",
    cursor: "pointer"
  },
  buttonDanger: {
    padding: "10px 12px",
    borderRadius: 10,
    border: "1px solid #b00020",
    background: "#b00020",
    color: "#fff",
    cursor: "pointer"
  },
  textArea: { marginTop: 10, padding: 12, borderRadius: 12, border: "1px dashed #ccc", background: "#fafafa" },
  transcript: { whiteSpace: "pre-wrap", lineHeight: 1.35, marginTop: 6 },
  muted: { color: "#666" },
  mutedSmall: { color: "#666", fontSize: 13 },
  kv: { marginTop: 10, display: "grid", gap: 4 },
  error: {
    marginTop: 12,
    padding: 12,
    borderRadius: 12,
    background: "#fff3f4",
    border: "1px solid #ffd0d5",
    color: "#7a0013"
  },
  tableWrap: { overflowX: "auto", marginTop: 10 },
  table: { width: "100%", borderCollapse: "separate", borderSpacing: 0 },
  th: { textAlign: "left", padding: "10px 10px", borderBottom: "1px solid #eee", fontSize: 13, color: "#444" },
  thQty: {
    textAlign: "right",
    padding: "10px 10px",
    borderBottom: "1px solid #eee",
    fontSize: 13,
    color: "#444",
    width: 120
  },
  thActions: {
    textAlign: "right",
    padding: "10px 10px",
    borderBottom: "1px solid #eee",
    fontSize: 13,
    color: "#444",
    width: 150
  },
  td: { padding: "10px 10px", borderBottom: "1px solid #f3f3f3" },
  tdQty: {
    padding: "10px 10px",
    borderBottom: "1px solid #f3f3f3",
    textAlign: "right"
  },
  tdActions: {
    padding: "10px 10px",
    borderBottom: "1px solid #f3f3f3",
    textAlign: "right"
  },
  inputInline: { width: "100%", padding: "8px 10px", borderRadius: 10, border: "1px solid #ddd" },
  buttonSmall: {
    padding: "7px 10px",
    borderRadius: 10,
    border: "1px solid #222",
    background: "#222",
    color: "#fff",
    cursor: "pointer"
  },
  buttonSecondarySmall: {
    padding: "7px 10px",
    borderRadius: 10,
    border: "1px solid #bbb",
    background: "#fff",
    color: "#111",
    cursor: "pointer"
  },
  buttonDangerSmall: {
    padding: "7px 10px",
    borderRadius: 10,
    border: "1px solid #b00020",
    background: "#b00020",
    color: "#fff",
    cursor: "pointer"
  },
  summaryGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
    gap: 10,
    marginTop: 10
  },
  summaryItem: {
    border: "1px solid #eee",
    borderRadius: 14,
    padding: 12,
    background: "#fafafa"
  },
  footer: { marginTop: 16, paddingBottom: 10 }
};