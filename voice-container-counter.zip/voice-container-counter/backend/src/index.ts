import express from "express";
import cors from "cors";
import { createContainer, getContainer, addLine, updateLine, getSummary } from "./store.js";
import { parseDictationText } from "./parsing.js";

const app = express();
app.use(express.json({ limit: "1mb" }));

// utile si jamais tu appelles le backend directement sans proxy
app.use(
  cors({
    origin: true,
    credentials: false
  })
);

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function isValidNumber(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}

app.get("/health", (_req, res) => res.json({ ok: true }));

// POST /parse
app.post("/parse", (req, res) => {
  const text = (req.body as any)?.text;
  if (!isNonEmptyString(text)) {
    return res.status(400).json({ error: "body.text (string) est requis" });
  }
  const lines = parseDictationText(text);
  return res.json({ lines });
});

// POST /containers
app.post("/containers", (req, res) => {
  const label = (req.body as any)?.label;
  if (!isNonEmptyString(label)) {
    return res.status(400).json({ error: "body.label (string) est requis" });
  }
  const c = createContainer(label.trim());
  return res.status(201).json(c);
});

// GET /containers/:id
app.get("/containers/:id", (req, res) => {
  const c = getContainer(req.params.id);
  if (!c) return res.status(404).json({ error: "Container introuvable" });
  return res.json(c);
});

// POST /containers/:id/lines
app.post("/containers/:id/lines", (req, res) => {
  const { itemLabel, quantity } = req.body as any;
  if (!isNonEmptyString(itemLabel)) {
    return res.status(400).json({ error: "body.itemLabel (string) est requis" });
  }
  if (!isValidNumber(quantity)) {
    return res.status(400).json({ error: "body.quantity (number) est requis" });
  }

  const c = addLine(req.params.id, itemLabel.trim(), quantity);
  if (!c) return res.status(404).json({ error: "Container introuvable" });

  return res.status(201).json(c);
});

// PUT /containers/:id/lines/:lineId
app.put("/containers/:id/lines/:lineId", (req, res) => {
  const patch: { itemLabel?: unknown; quantity?: unknown } = req.body ?? {};

  const outPatch: { itemLabel?: string; quantity?: number } = {};
  if (patch.itemLabel !== undefined) {
    if (!isNonEmptyString(patch.itemLabel)) {
      return res.status(400).json({ error: "body.itemLabel doit être une string non vide" });
    }
    outPatch.itemLabel = (patch.itemLabel as string).trim();
  }
  if (patch.quantity !== undefined) {
    if (!isValidNumber(patch.quantity)) {
      return res.status(400).json({ error: "body.quantity doit être un number" });
    }
    outPatch.quantity = patch.quantity as number;
  }

  const c = updateLine(req.params.id, req.params.lineId, outPatch);
  if (!c) return res.status(404).json({ error: "Container ou ligne introuvable" });

  return res.json(c);
});

// GET /containers/:id/summary
app.get("/containers/:id/summary", (req, res) => {
  const summary = getSummary(req.params.id);
  if (!summary) return res.status(404).json({ error: "Container introuvable" });
  return res.json(summary);
});

const port = Number(process.env.PORT ?? 4318);
app.listen(port, "0.0.0.0", () => {
  // eslint-disable-next-line no-console
  console.log(`[backend] listening on http://0.0.0.0:${port}`);
});